import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
app.use(cors());
app.use(express.json({ limit: '32kb' }));
const port = process.env.PORT || 3000;
const apiKey = process.env.OPENAI_API_KEY;
const client = apiKey ? new OpenAI({ apiKey }) : null;

app.get('/health', (_req, res) => res.json({ ok: true, service: 'NEXA AI' }));
app.post('/api/chat', async (req, res) => {
  try {
    if (!client) return res.status(503).json({ error: 'NEXA server is missing its private AI key. Ask your adult project supervisor to configure it.' });
    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const safe = messages.slice(-12).filter(m => ['user','assistant'].includes(m?.role) && typeof m?.content === 'string').map(m => ({ role: m.role, content: m.content.slice(0, 4000) }));
    if (!safe.length || safe[safe.length - 1].role !== 'user') return res.status(400).json({ error: 'Send a message first.' });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-5.4-mini',
      instructions: 'You are NEXA, a helpful, age-appropriate personal AI assistant. Introduction: “I’m NEXA, your personal AI assistant, learning and growing with you.” Adapt your tone: professional for tasks, friendly for conversation, patient and clear when teaching. Be honest about uncertainty. Do not claim to control the user’s phone or access private apps unless a real permissioned feature exists. Do not ask for passwords, API keys, or sensitive personal information. Keep answers clear and useful.',
      input: safe,
      max_output_tokens: 700,
      store: false
    });
    res.json({ reply: response.output_text || 'I could not produce a reply. Please try again.' });
  } catch (err) {
    console.error('NEXA AI error:', err?.message || err);
    res.status(500).json({ error: 'NEXA could not reach its AI service. Check the server configuration and try again.' });
  }
});
app.listen(port, () => console.log(`NEXA server listening on ${port}`));
