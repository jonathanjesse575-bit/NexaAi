NEXA AI — Voice + AI connection build

WHAT THIS BUILD DOES
- Adds clearer microphone listening, interim speech transcription, tap-again-to-stop, and microphone error messages.
- Uses browser speech recognition (availability varies by browser; internet may be required).
- Sends chat history to a private backend endpoint and speaks the AI response aloud.
- Includes a Node.js backend using the OpenAI Responses API. The API key stays on the server, never in the app.

IMPORTANT
This ZIP is not a fully connected live AI service until the backend is deployed and configured with an API key. Do not paste an API key into the website or send it in chat. API usage may cost money. Because the developer is 17, a parent/legal guardian must review the provider terms and give required permission and supervise any account, billing, and key setup. Do not bypass age checks.

DEPLOYMENT OVERVIEW
1. Deploy the NEXA_AI_App folder as a static site (Netlify Drop can host the frontend).
2. Deploy server.js + package.json as a separate Node web service (for example, a Node hosting provider that supports environment variables).
3. On the backend host, set OPENAI_API_KEY as a PRIVATE environment variable and optionally OPENAI_MODEL=gpt-5.4-mini. An adult supervisor should manage this account/key and billing.
4. Keep the frontend and backend on HTTPS.
5. Open the NEXA site, tap Settings, paste the backend HTTPS base URL (for example https://your-nexa-server.example), and reload.
6. Test /health on the backend URL; it should return {"ok":true,"service":"NEXA AI"}.

VOICE
Open the hosted app in Chrome. Grant microphone permission when asked. Tap the microphone to start and tap again to stop. SpeechRecognition is not supported in every browser and may rely on a network recognition service. Typing remains available as a fallback.

PRIVACY
This build sends the last 12 chat messages to the configured AI backend when you chat. The backend sets store:false for Responses API requests, but review the provider's current data policies before real users use the app. Do not collect sensitive data. Chat history is kept only in the current page session in this build.
