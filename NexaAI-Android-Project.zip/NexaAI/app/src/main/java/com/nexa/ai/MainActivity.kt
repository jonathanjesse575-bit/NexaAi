package com.nexa.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Navy = Color(0xFF101B36)
private val Blue = Color(0xFF2878F0)
private data class ChatLine(val fromUser: Boolean, val text: String)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent { NexaScreen(
            onSpeak = { speak(it) },
            onDial = { number -> startActivity(Intent(Intent.ACTION_DIAL).apply { data = android.net.Uri.parse("tel:$number") }) }
        ) }
    }
    override fun onInit(status: Int) { if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nexa_reply") }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

@Composable
private fun NexaScreen(onSpeak: (String) -> Unit, onDial: (String) -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf(ChatLine(false, "Hello! I'm NEXA AI. Tap the microphone or type a message to get started.")) }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        listening = false
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) { input = spoken }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startSpeech(speechLauncher) else messages.add(ChatLine(false, "Microphone permission was not granted. You can still type to me."))
    }

    fun send() {
        val text = input.trim(); if (text.isEmpty()) return
        messages.add(ChatLine(true, text)); input = ""
        val lower = text.lowercase()
        val reply = when {
            lower.startsWith("call ") -> {
                val number = text.removePrefix("call ").trim()
                if (number.matches(Regex("[+0-9 ()-]{3,}"))) { onDial(number); "I've opened the phone dialler with $number. Review it and press call yourself." }
                else "Please say: call, followed by a phone number."
            }
            lower.contains("hello") || lower.contains("hi") -> "Hello! I'm ready to help. What would you like to do?"
            lower.contains("your name") -> "My name is NEXA AI — Your Voice. Your Assistant. Your Control."
            lower.contains("help") -> "For this first version, try greeting me or typing 'call' followed by a phone number. AI answers and more phone features will be connected in later versions."
            else -> "I heard you say: $text. My live AI brain is not connected yet; this starter version handles basic demo commands."
        }
        messages.add(ChatLine(false, reply)); onSpeak(reply)
    }

    Column(Modifier.fillMaxSize().background(Color(0xFFF5F7FC))) {
        Column(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 22.dp, vertical = 24.dp)) {
            Text("NEXA AI", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("Your Voice. Your Assistant. Your Control.", color = Color(0xFFBBD2FF), fontSize = 12.sp)
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(Color(0xFF55D69E), CircleShape))
                Spacer(Modifier.width(8.dp)); Text("READY TO ASSIST", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(messages) { line ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                    Surface(color = if (line.fromUser) Blue else Color.White, shape = RoundedCornerShape(18.dp), shadowElevation = 1.dp, modifier = Modifier.widthIn(max = 310.dp)) {
                        Text(line.text, Modifier.padding(14.dp), color = if (line.fromUser) Color.White else Navy, fontSize = 14.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message NEXA...") }, shape = RoundedCornerShape(24.dp), singleLine = true)
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { if (input.isNotBlank()) send() }, modifier = Modifier.size(48.dp).background(Blue, CircleShape)) { Icon(Icons.Default.Send, contentDescription = "Send", tint = Color.White) }
        }
        Button(onClick = {
            listening = true
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startSpeech(speechLauncher)
            else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }, modifier = Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 20.dp).height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Navy), shape = RoundedCornerShape(18.dp)) {
            Icon(Icons.Default.Mic, contentDescription = null); Spacer(Modifier.width(10.dp)); Text(if (listening) "LISTENING..." else "TAP TO SPEAK", fontWeight = FontWeight.Bold)
        }
    }
}

private fun startSpeech(launcher: androidx.activity.result.ActivityResultLauncher<Intent>) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to NEXA AI")
    }
    try { launcher.launch(intent) } catch (_: Exception) { }
}
